from django.http import HttpResponse

def index(request):
    return HttpResponse("Hernandez says Hello! :) ")  # Replace 'Hernandez' with your last name
